// This runs in the background so notifications arrive even when the app/tab is closed.
// It must live at the site root (/firebase-messaging-sw.js) — Firebase requires that path.
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-app-compat.js')
importScripts('https://www.gstatic.com/firebasejs/10.14.1/firebase-messaging-compat.js')

firebase.initializeApp({
  apiKey: 'AIzaSyCVI7TqzqZTJyVdieQK9d8r5Kmxvzz73Rs',
  authDomain: 'masahatna.firebaseapp.com',
  projectId: 'masahatna',
  storageBucket: 'masahatna.firebasestorage.app',
  messagingSenderId: '842825621418',
  appId: '1:842825621418:web:bc1e30ae89cbcbf5d355d3',
})

const messaging = firebase.messaging()

messaging.onBackgroundMessage((payload) => {
  const title = (payload.notification && payload.notification.title) || 'مساحتنا'
  const body = (payload.notification && payload.notification.body) || ''
  self.registration.showNotification(title, {
    body,
    icon: '/icons/icon-192.png',
    badge: '/icons/icon-192.png',
    dir: 'rtl',
  })
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      if (list.length > 0) return list[0].focus()
      return self.clients.openWindow('/')
    }),
  )
})
